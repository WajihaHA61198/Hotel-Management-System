﻿namespace HotelSytem
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.iconButtonRoom = new FontAwesome.Sharp.IconButton();
            this.iconButtonReservation = new FontAwesome.Sharp.IconButton();
            this.iconButtonClient = new FontAwesome.Sharp.IconButton();
            this.pictureBoxlogo = new System.Windows.Forms.PictureBox();
            this.panelMain = new System.Windows.Forms.Panel();
            this.labelTime = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxlogo)).BeginInit();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelMenu.Controls.Add(this.iconButtonRoom);
            this.panelMenu.Controls.Add(this.iconButtonReservation);
            this.panelMenu.Controls.Add(this.iconButtonClient);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Location = new System.Drawing.Point(-1, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(378, 848);
            this.panelMenu.TabIndex = 0;
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.pictureBoxlogo);
            this.panelLogo.Location = new System.Drawing.Point(3, 3);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(372, 223);
            this.panelLogo.TabIndex = 0;
            // 
            // iconButtonRoom
            // 
            this.iconButtonRoom.FlatAppearance.BorderSize = 0;
            this.iconButtonRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButtonRoom.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.iconButtonRoom.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButtonRoom.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconButtonRoom.IconChar = FontAwesome.Sharp.IconChar.HospitalUser;
            this.iconButtonRoom.IconColor = System.Drawing.Color.LightGray;
            this.iconButtonRoom.IconSize = 30;
            this.iconButtonRoom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonRoom.Location = new System.Drawing.Point(0, 334);
            this.iconButtonRoom.Name = "iconButtonRoom";
            this.iconButtonRoom.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.iconButtonRoom.Rotation = 0D;
            this.iconButtonRoom.Size = new System.Drawing.Size(360, 97);
            this.iconButtonRoom.TabIndex = 3;
            this.iconButtonRoom.Text = "Room";
            this.iconButtonRoom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonRoom.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButtonRoom.UseVisualStyleBackColor = true;
            this.iconButtonRoom.Click += new System.EventHandler(this.iconButtonRoom_Click);
            // 
            // iconButtonReservation
            // 
            this.iconButtonReservation.FlatAppearance.BorderSize = 0;
            this.iconButtonReservation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButtonReservation.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.iconButtonReservation.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButtonReservation.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconButtonReservation.IconChar = FontAwesome.Sharp.IconChar.Clock;
            this.iconButtonReservation.IconColor = System.Drawing.Color.LightGray;
            this.iconButtonReservation.IconSize = 30;
            this.iconButtonReservation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonReservation.Location = new System.Drawing.Point(0, 437);
            this.iconButtonReservation.Name = "iconButtonReservation";
            this.iconButtonReservation.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.iconButtonReservation.Rotation = 0D;
            this.iconButtonReservation.Size = new System.Drawing.Size(357, 97);
            this.iconButtonReservation.TabIndex = 2;
            this.iconButtonReservation.Text = "Reservation";
            this.iconButtonReservation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonReservation.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButtonReservation.UseVisualStyleBackColor = true;
            this.iconButtonReservation.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // iconButtonClient
            // 
            this.iconButtonClient.FlatAppearance.BorderSize = 0;
            this.iconButtonClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButtonClient.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.iconButtonClient.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButtonClient.ForeColor = System.Drawing.Color.LightGray;
            this.iconButtonClient.IconChar = FontAwesome.Sharp.IconChar.ListAlt;
            this.iconButtonClient.IconColor = System.Drawing.Color.LightGray;
            this.iconButtonClient.IconSize = 30;
            this.iconButtonClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonClient.Location = new System.Drawing.Point(3, 232);
            this.iconButtonClient.Name = "iconButtonClient";
            this.iconButtonClient.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.iconButtonClient.Rotation = 0D;
            this.iconButtonClient.Size = new System.Drawing.Size(357, 96);
            this.iconButtonClient.TabIndex = 1;
            this.iconButtonClient.Text = "Client";
            this.iconButtonClient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButtonClient.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButtonClient.UseVisualStyleBackColor = true;
            this.iconButtonClient.Click += new System.EventHandler(this.iconButtonClient_Click);
            // 
            // pictureBoxlogo
            // 
            this.pictureBoxlogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxlogo.Image = global::HotelSytem.Properties.Resources.tree;
            this.pictureBoxlogo.Location = new System.Drawing.Point(10, 9);
            this.pictureBoxlogo.Name = "pictureBoxlogo";
            this.pictureBoxlogo.Size = new System.Drawing.Size(344, 204);
            this.pictureBoxlogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxlogo.TabIndex = 0;
            this.pictureBoxlogo.TabStop = false;
            this.pictureBoxlogo.Click += new System.EventHandler(this.pictureBoxlogo_Click);
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(101)))), ((int)(((byte)(103)))));
            this.panelMain.Controls.Add(this.labelDate);
            this.panelMain.Controls.Add(this.labelTime);
            this.panelMain.Location = new System.Drawing.Point(365, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1207, 848);
            this.panelMain.TabIndex = 1;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.labelTime.Location = new System.Drawing.Point(52, 31);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(105, 38);
            this.labelTime.TabIndex = 0;
            this.labelTime.Text = "Time";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(101)))), ((int)(((byte)(103)))));
            this.labelDate.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(155)))), ((int)(((byte)(211)))));
            this.labelDate.Location = new System.Drawing.Point(63, 92);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(76, 29);
            this.labelDate.TabIndex = 1;
            this.labelDate.Text = "Date";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1574, 842);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelMenu);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxlogo)).EndInit();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelLogo;
        private FontAwesome.Sharp.IconButton iconButtonRoom;
        private FontAwesome.Sharp.IconButton iconButtonReservation;
        private FontAwesome.Sharp.IconButton iconButtonClient;
        private System.Windows.Forms.PictureBox pictureBoxlogo;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelTime;
    }
}
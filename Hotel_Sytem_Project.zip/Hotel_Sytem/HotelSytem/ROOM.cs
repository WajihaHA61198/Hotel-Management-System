﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    class ROOM
    {
        //connection
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");

        public DataTable roomtypeList()
        {
            //combo bex

            SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[room_cat]", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return dt;
        }
        //========================================================================

        public DataTable roomBytype(int room_type) //EDIT--> show the rrom which are free
        {
            //combo bex

            SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[rooms] where room_type = @rtype AND free = 'Yes'", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            sda.Parameters.Add("@rtype", SqlDbType.Int).Value = room_type;

            adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return dt;
        }
        //========================================================================

            //in cell contant click
        public int GetroomBytype(int room_id)   //room_id
        {
            //combo bex

            SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[rooms] where room_id = @id", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            sda.Parameters.Add("@id", SqlDbType.Int).Value = room_id;

            adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return Convert.ToInt32(dt.Rows[0][1].ToString());
            //return Convert.ToInt32(dt.Rows[0].ToString());
        }
        //========================================================================

        public bool setRoomToNo(int room_type) 
        {
            //combo bex

            SqlCommand sda = new SqlCommand("update [HotelSystem].[dbo].[rooms] SET free = 'No' WHERE room_id = @num", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            sda.Parameters.Add("@num", SqlDbType.Int).Value = room_type;

            con.Open();

            if(sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }

            /*adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return dt;*/
        }
        //========================================================================

        public bool setRoomFree(int room_type, String Yes_or_No)   //Yes_No
        {
            //combo bex

            SqlCommand sda = new SqlCommand("update [HotelSystem].[dbo].[rooms] SET free = @yes_no WHERE room_id = @num", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            sda.Parameters.Add("@num", SqlDbType.Int).Value = room_type;
            //
            sda.Parameters.Add("@yes_no", SqlDbType.VarChar).Value= Yes_or_No;
            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }

            /*adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return dt;*/
        }
        //========================================================================

        /* public DataTable roomBytypeYes(int room_type)
         {
             //combo bex

             SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[rooms] where room_type = @rtype AND free = 'Yes'", con);
             SqlDataAdapter adapter = new SqlDataAdapter();
             DataTable dt = new DataTable();

             sda.Parameters.Add("@rtype", SqlDbType.Int).Value = room_type;

             adapter.SelectCommand = sda;
             adapter.Fill(dt);

             return dt;
         }*///======================================================================

        public bool addRoom(int room_id, int room_type, int phone, String free)
        {
           // con.Open();
            SqlCommand sda = new SqlCommand();
           // String qry = "Insert into [HotelSystem].[dbo].[rooms] values(" + room_id + ", " + room_type + ", " + phone +",'"+ free +"'";
           
            String qry = "Insert into [HotelSystem].[dbo].[rooms] (room_id, room_type, phone, free) values (@num, @tp, @phn, @free)";
            //SqlCommand sc = new SqlCommand(qry, con);

            sda.CommandText = qry;
            sda.Connection = con;

            sda.Parameters.Add("@num",SqlDbType.Int).Value = room_id;
            sda.Parameters.Add("@tp",SqlDbType.Int).Value = room_type;
            sda.Parameters.Add("@phn",SqlDbType.Int).Value = phone;
            sda.Parameters.Add("@free",SqlDbType.VarChar).Value = free;

            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //=======================================================================

        public bool Update_Room(int room_id, int room_type, int phone, String free)
        {
            // con.Open();
            SqlCommand sda = new SqlCommand();
            // String qry = "Insert into [HotelSystem].[dbo].[rooms] values(" + room_id + ", " + room_type + ", " + phone +",'"+ free +"'";

            String qry = "update [HotelSystem].[dbo].[rooms] SET room_type = @tp, phone= @phn, free= @free WHERE room_id= @num";

           // String qry = "update [HotelSystem].[dbo].[Client] set fname='" + f_name + "', lname='" + l_name + "', phone=" + iphone + ", country='" + country + "' where id=" + ID;
            //SqlCommand sc = new SqlCommand(qry, con);

            sda.CommandText = qry;
            sda.Connection = con;

            sda.Parameters.Add("@num", SqlDbType.Int).Value = room_id;
            sda.Parameters.Add("@tp", SqlDbType.Int).Value = room_type;
            sda.Parameters.Add("@phn", SqlDbType.Int).Value = phone;
            sda.Parameters.Add("@free", SqlDbType.VarChar).Value = free;

            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //======================================================================
        public bool delete_room(int room_id)
        {
            // con.Open();
            SqlCommand sda = new SqlCommand();

            String qry = "delete from [HotelSystem].[dbo].[rooms] WHERE room_id= @num";

            sda.CommandText = qry;
            sda.Connection = con;

            sda.Parameters.Add("@num", SqlDbType.Int).Value = room_id;

            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //=======================================================================
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    public partial class ManageClients : Form
    {
        //connection
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");

        public ManageClients()
        {
            InitializeComponent();
            show();     //table DB
        }
        //====================================================================

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //RESET FIELDS
            textBoxID.Text = "";
            textBoxFirstName.Text = "";
            textBoxLastName.Text = "";
            textBoxPhone.Text = "";
            textBoxCountry.Text = "";
        }
        //====================================================================

        private void button1_Click(object sender, EventArgs e)
        {
            //ADD CLIENTS
            try
            {
                con.Open();

                String id = textBoxID.Text.ToString();
                int ID = Int16.Parse(id);

                String f_name = textBoxFirstName.Text.ToString();
                String l_name = textBoxLastName.Text.ToString();               

                String phone = textBoxPhone.Text.ToString();
                long iphone = Int64.Parse(phone);

                String country = textBoxCountry.Text.ToString();
                
                String qry = "insert into [HotelSystem].[dbo].[Client] values(" + ID + ",'" + f_name + "','" + l_name + "'," + iphone + ",'" + country + "')";

                SqlCommand sc = new SqlCommand(qry, con);
                int n = sc.ExecuteNonQuery();

                if (n >= 1)
                    // MessageBox.Show(" Customer Registered Successfuly: " + f_name);
                    MessageBox.Show("Client inserted successfully", "Add Customer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Customer not Registered.");

                button4_Click(sender, e);   // self reset
                show();
                con.Close();
            }
            catch (System.Exception exp)
            {
                MessageBox.Show("Error is:--- " + exp.ToString());
            }
        }
        //====================================================================================

        void show()
        {
            //DB table show
            SqlDataAdapter sda = new SqlDataAdapter("select *from [HotelSystem].[dbo].[Client]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.Rows.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();

                dataGridView1.Rows[n].Cells[0].Value = dr[0].ToString();
                dataGridView1.Rows[n].Cells[1].Value = dr[1].ToString();
                dataGridView1.Rows[n].Cells[2].Value = dr[2].ToString();
                dataGridView1.Rows[n].Cells[3].Value = dr[3].ToString();
                dataGridView1.Rows[n].Cells[4].Value = dr[4].ToString();
            }
        }
        //====================================================================================

        private void button2_Click(object sender, EventArgs e)
        {
            //UPDATE BTN
            try
            {
                con.Open();

                String id = textBoxID.Text.ToString();
                int ID = Int16.Parse(id);

                String f_name = textBoxFirstName.Text.ToString();
                String l_name = textBoxLastName.Text.ToString();

                String phone = textBoxPhone.Text.ToString();
                long iphone = Int64.Parse(phone);

                String country = textBoxCountry.Text.ToString();

                String qry = "update [HotelSystem].[dbo].[Client] set fname='"+f_name +"', lname='"+l_name+"', phone="+ iphone +", country='"+country+"' where id="+ ID ;
               // "update Student set saddress='" + add + "', phone=" + iphone + ", sem=" + isem + ", branch='" + branch + "' where sname='" + name + "'";
                SqlCommand sc = new SqlCommand(qry, con);

                int i = sc.ExecuteNonQuery();

                if (i >= 1)
                    MessageBox.Show(" Customer Updated Successfuly!", "Update Customer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Customer not Updated.");

                button4_Click(sender, e);
                show();
                con.Close();
            }
            catch (System.Exception exp)
            {
                MessageBox.Show("Error is:--- " + exp.ToString());
            }
        }
        //===============================================================================================

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //CELL CONTENT CLICK
            /*textBoxID.Text =        dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBoxFirstName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBoxLastName.Text =  dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBoxPhone.Text =     dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBoxCountry.Text =   dataGridView1.SelectedRows[0].Cells[4].Value.ToString();*/

            textBoxID.Text =        dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBoxFirstName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBoxLastName.Text =  dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBoxPhone.Text =     dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBoxCountry.Text =   dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }
        //====================================================================================

        private void button3_Click(object sender, EventArgs e)
        {
            //DELETE BTN
            try
            {
                con.Open();

                String f_name = textBoxFirstName.Text.ToString();

                String qry = "delete from [HotelSystem].[dbo].[Client] where fname='" + f_name + "'";
                SqlCommand sc = new SqlCommand(qry, con);
                int i = sc.ExecuteNonQuery();

                if (i >= 1)
                    MessageBox.Show(" Customer Delete Successfuly! ","Customer Delete", MessageBoxButtons.OK,MessageBoxIcon.Information);
                else
                    MessageBox.Show("Customer not deleted.");

                button4_Click(sender, e);
                show();
                con.Close();
            }
            catch (System.Exception exp)
            {
                MessageBox.Show("Error is:--- " + exp.ToString());
            }
        }
        //====================================================================================
    }
}

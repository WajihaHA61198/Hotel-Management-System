﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;

namespace HotelSytem
{
    public partial class Main : Form
    {
        //Fields
        private IconButton currentBtn;
        private Panel leftBorderBtn;

        //constructor
        public Main()
        {
            InitializeComponent();
            //
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7, 61);
            panelMenu.Controls.Add(leftBorderBtn);
        }//================================================

        //structs
        private struct RGBColors
        {
            public static Color color1 = Color.FromArgb(172, 126, 242);
            public static Color color2 = Color.FromArgb(249, 118, 176);
            public static Color color3 = Color.FromArgb(253, 138, 114);
        }//================================================

        //Methods
        private void ActivateButton(object senderbtn, Color color)
        {
            if(senderbtn != null)
            {
                DisableBtn();
                //btn
                currentBtn = (IconButton)senderbtn;
                currentBtn.BackColor = Color.FromArgb(37, 36, 81);
                currentBtn.ForeColor = color;
                currentBtn.TextAlign = ContentAlignment.MiddleCenter;
                currentBtn.IconColor = color;
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentBtn.ImageAlign = ContentAlignment.MiddleRight;
                //left border btn
                leftBorderBtn.BackColor = color;
                leftBorderBtn.Location = new Point(0, currentBtn.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();
            }
        }//=================================================
        //
        private void DisableBtn()
        {
            if(currentBtn != null)
            {
                currentBtn.BackColor = Color.FromArgb(64, 64, 64);
                currentBtn.ForeColor = Color.LightGray;
                currentBtn.TextAlign = ContentAlignment.MiddleLeft;
                currentBtn.IconColor = Color.LightGray;
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }//=================================================
        //
        private void Reset()
        {
            DisableBtn();
            leftBorderBtn.Visible = false;
        }//==================================================

        private void iconButton1_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color3);
        }//=================================================

        private void iconButtonClient_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color1);
        }//=================================================

        private void iconButtonRoom_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color2);
        }//================================================

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxlogo_Click(object sender, EventArgs e)
        {
            Reset();
        }//==============================================

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {
            labelTime.Text = DateTime.Now.ToLongTimeString();
            labelDate.Text = DateTime.Now.ToLongDateString();
        }//===============================================
    }
}

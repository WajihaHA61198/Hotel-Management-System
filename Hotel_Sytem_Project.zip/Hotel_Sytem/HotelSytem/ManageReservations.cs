﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    public partial class ManageReservations : Form
    {
        //connection
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");
        public ManageReservations()
        {
            InitializeComponent();
           // show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //reset btn
            textBoxReserveID.Text = "";
            textBoxClientID.Text = "";
            comboBoxRoomType.SelectedIndex = -1;
            comboBoxRoomNo.SelectedIndex = -1;
            dateTimePickerIN.Value= DateTime.Now;
            dateTimePickerOut.Value = DateTime.Now;               
        }
        //================================================================


            //***
        ROOM room = new ROOM();
        RESERVATION reserve = new RESERVATION();

        private void ManageReservations_Load(object sender, EventArgs e)
        {
            //room type
            comboBoxRoomType.DataSource = room.roomtypeList();
            comboBoxRoomType.DisplayMember = "label";
            comboBoxRoomType.ValueMember = "category_id";

            //room number
            /*int room_type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
            comboBoxRoomNo.DataSource = room.roomBytype(room_type);
            comboBoxRoomNo.DisplayMember = "room_id";
            comboBoxRoomNo.ValueMember = "room_id";*/

            dataGridView1.DataSource = reserve.getAllReserve();
        }
        //=============================================================

        private void comboBoxRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //combo RoomType
            //room number
            try
            {
                int room_type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
                comboBoxRoomNo.DataSource = room.roomBytype(room_type);
                comboBoxRoomNo.DisplayMember = "room_id";
                comboBoxRoomNo.ValueMember = "room_id";
            }
            catch (Exception )
            {

            }          
        }
        //===============================================================

        private void button1_Click(object sender, EventArgs e)
        {
            //Add btn
            int id = Convert.ToInt32(textBoxClientID.Text);
            int roomNumber = Convert.ToInt32(comboBoxRoomNo.SelectedValue);
            DateTime dateIN = dateTimePickerIN.Value;
            DateTime dateOUT = dateTimePickerOut.Value;


            if(dateIN < DateTime.Now)
            {
                MessageBox.Show("Date must be greater or atleast today","Invalid Date IN!",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }else if(dateOUT < dateIN)
            {
                MessageBox.Show("Date must be greater or atleast today", "Invalid Date OUT!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (reserve.add_Reservation(roomNumber, id, dateIN, dateOUT))
                {
                    //set room free to No
                    room.setRoomToNo(roomNumber);
                    //
                    dataGridView1.DataSource = reserve.getAllReserve();
                    MessageBox.Show("New reservation added", "Add Reservation!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Reservation failed!");
                }
            }
            button4_Click(sender, e);
        }
        //===============================================================

        private void button2_Click(object sender, EventArgs e)
        {
            //Update btn
            try
            {
                int reserve_id = Convert.ToInt32(textBoxReserveID.Text);
                int id = Convert.ToInt32(textBoxClientID.Text);
                int roomNumber = Convert.ToInt32(comboBoxRoomNo.SelectedValue);
                DateTime dateIN = dateTimePickerIN.Value;
                DateTime dateOUT = dateTimePickerOut.Value;

                if (dateIN < DateTime.Now)
                {
                    MessageBox.Show("Date must be greater or atleast today", "Invalid Date IN!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (dateOUT < dateIN)
                {
                    MessageBox.Show("Date must be greater or atleast today", "Invalid Date OUT!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (reserve.Update_Reservation(reserve_id, roomNumber, id, dateIN, dateOUT))
                    {
                        room.setRoomToNo(roomNumber);
                        MessageBox.Show("New reservation added", "Add Reservation!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Reservation failed!");
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Reservation not Updated.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }           
        }
        
        //================================================================

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //CELL CONTENT CLICK

            textBoxReserveID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            //textBoxClientID.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            //comboBoxRoomNo.SelectedValue = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            int room_id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
            comboBoxRoomType.SelectedValue = room.GetroomBytype(room_id);

            comboBoxRoomNo.SelectedValue = room_id;
            textBoxClientID.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }
        //================================================================

        private void button3_Click(object sender, EventArgs e)
        {
            //DELETE BTN
            try
            {
                int reserve_id = Convert.ToInt32(textBoxReserveID.Text);
                //
                int roomNumber = Convert.ToInt32(comboBoxRoomNo.SelectedValue);

                if (reserve.delete_Reservation(reserve_id))
                {
                    dataGridView1.DataSource = reserve.getAllReserve();

                    room.setRoomFree(roomNumber,"Yes");
                    MessageBox.Show("Reservation deleted successfully", "delete Room", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Reservation delete request fail", "Room not delete", MessageBoxButtons.OK);
                }
                button4_Click(sender, e);
            }
            catch (Exception)
            {
                MessageBox.Show("Reservation not Updated.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }      
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        //===================================================================================
    }
}

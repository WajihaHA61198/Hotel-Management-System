﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    public partial class ManageRooms : Form
    {
        //connection
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");

        public ManageRooms()
        {
            InitializeComponent();
            show();
        }
        //======================================================

        private void button4_Click(object sender, EventArgs e)
        {
            //Reset btn
            textBoxRoomNo.Text = "";
            comboBoxRoomType.SelectedIndex = -1;
            textBoxPhone.Text = "";
        }
        //=======================================================

        private void button1_Click(object sender, EventArgs e)
        {
            //Add btn
            int room_id = Convert.ToInt32(textBoxRoomNo.Text);
            int room_type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
            int phone = Convert.ToInt32(textBoxPhone.Text);
//
            String free = "";

            if (radioButtonYes.Checked)
            {
                free = "Yes";
            }
            else if (radioButtonNo.Checked)
            {
                free = "No";
            }

            if (room.addRoom(room_id, room_type, phone, free))
            {
                MessageBox.Show("Room added successfully", "Add Room", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Room added request fail", "Room not Add", MessageBoxButtons.OK);
            }
            button4_Click(sender, e);
            show();
        }
        //=======================================================

        private void comboBoxRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //combo
           /* con.Open();
            // SqlDataAdapter sda = new SqlDataAdapter("select *from [HotelSystem].[dbo].[room_cat]", con);
            SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[room_cat]", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            adapter.SelectCommand = sda;
            adapter.Fill(dt);*/
           // sda.Fill(dt);
        }
        //=======================================================

        ROOM room = new ROOM();
        private void ManageRooms_Load(object sender, EventArgs e)
        {
            comboBoxRoomType.DataSource = room.roomtypeList();
            comboBoxRoomType.DisplayMember = "label";
            comboBoxRoomType.ValueMember = "category_id";
        }
        //=======================================================
        void show()
        {
            //DB table show
            SqlDataAdapter sda = new SqlDataAdapter("select *from [HotelSystem].[dbo].[rooms]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.Rows.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();

                dataGridView1.Rows[n].Cells[0].Value = dr[0].ToString();
                dataGridView1.Rows[n].Cells[1].Value = dr[1].ToString();
                dataGridView1.Rows[n].Cells[2].Value = dr[2].ToString();
                dataGridView1.Rows[n].Cells[3].Value = dr[3].ToString();
               // dataGridView1.Rows[n].Cells[4].Value = dr[4].ToString();
             
            }
        }
        //========================================================

         private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //CELL CONTENT CLICK

            textBoxRoomNo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            comboBoxRoomType.SelectedValue = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBoxPhone.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            //labelYes.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

            String free = dataGridView1.CurrentRow.Cells[3].Value.ToString();

            if (free.Equals("Yes"))
            {
                radioButtonYes.Checked = true;
            }
            else if (free.Equals("No"))
            {
                radioButtonNo.Checked = true;
            }
        }
        //===================================================================================

        private void button2_Click(object sender, EventArgs e)
        {
            //Update btn
            int room_id = Convert.ToInt32(textBoxRoomNo.Text);
            int room_type = Convert.ToInt32(comboBoxRoomType.SelectedValue.ToString());
            int phone = Convert.ToInt32(textBoxPhone.Text);
            String free = "";

            if (radioButtonYes.Checked)
            {
                free = "Yes";
            }
            else if(radioButtonNo.Checked)
            {
                free = "No";
            }


            if (room.Update_Room(room_id, room_type, phone, free))
            {
                MessageBox.Show("Room updated successfully", "update Room", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Room editing request fail", "Room not update", MessageBoxButtons.OK);
            }
            button4_Click(sender, e);
            show();
        }
        //===================================================================================

        private void button3_Click(object sender, EventArgs e)
        {
            //DELETE BTN
            int room_id = Convert.ToInt32(textBoxRoomNo.Text);


            if (room.delete_room(room_id))
            {
                MessageBox.Show("Room deleted successfully", "delete Room", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Room delete request fail", "Room not delete", MessageBoxButtons.OK);
            }
            button4_Click(sender, e);
            show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        //====================================================================================
    }
}

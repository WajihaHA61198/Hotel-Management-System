﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    public partial class Login : Form
    {
  

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //LOGIN BTN

            //connection
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select *from [HotelSystem].[dbo].[user] where username='" + textBoxUser.Text.ToString() + "'and password='" + textBoxPassword.Text.ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if(dt.Rows.Count > 0)
            {
                this.Hide();
                Main_Form mf = new Main_Form();
                //Main menu = new Main();
               // menu.Show();
                mf.Show();
                //MessageBox.Show("YES");
            }
            else
            {
                if (textBoxUser.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Enter your Username", "Empty Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (textBoxPassword.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Enter your Password", "Empty Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Username and password not Exist.", "Wrong ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //MessageBox.Show("NO");
            }
        }

        private void textBoxUser_Click(object sender, EventArgs e)
        {
            textBoxUser.Text = "";
           /* SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("select *from [HotelSystem].[dbo].[user] where username='" + textBoxUser.Text.ToString() + "'and password='" + textBoxPassword.Text.ToString() + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);*/
        }

        private void textBoxPassword_Click(object sender, EventArgs e)
        {
            textBoxPassword.UseSystemPasswordChar = true;
            textBoxPassword.Text = "wajiha";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            textBox1.Select();
        }
    }
}

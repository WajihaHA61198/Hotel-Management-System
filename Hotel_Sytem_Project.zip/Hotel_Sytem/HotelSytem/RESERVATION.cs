﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace HotelSytem
{
    class RESERVATION
    {
        //connection
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=HotelSystem;Integrated Security=True;Pooling=False");

        public DataTable getAllReserve()
        {
            //+ for combo box

            SqlCommand sda = new SqlCommand("select *from [HotelSystem].[dbo].[reservation]", con);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            adapter.SelectCommand = sda;
            adapter.Fill(dt);

            return dt;
        }
        //===============================================================================
        public bool add_Reservation(int roomNumber, int id, DateTime dateIN, DateTime dateOUT)
        {
            SqlCommand sda = new SqlCommand();
            String qry = "Insert into [HotelSystem].[dbo].[reservation] (roomNumber, id, dateIN, dateOUT) values (@rsnum, @cid, @in, @out)";

            sda.CommandText = qry;
            sda.Connection = con;

            sda.Parameters.Add("@rsnum", SqlDbType.Int).Value = roomNumber;
            sda.Parameters.Add("@cid", SqlDbType.Int).Value = id;
            sda.Parameters.Add("@in", SqlDbType.Date).Value = dateIN;
            sda.Parameters.Add("@out", SqlDbType.Date).Value = dateOUT;

            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //=======================================================================

        public bool Update_Reservation(int reserve_id, int roomNumber, int id, DateTime dateIN, DateTime dateOUT)
        {
            SqlCommand sda = new SqlCommand();
            String qry = "update [HotelSystem].[dbo].[reservation] SET roomNumber = @rsnum, id= @cid, dateIN= @in, dateOUT= @out WHERE room_id= @num";

            sda.CommandText = qry;
            sda.Connection = con;

            //sda.Parameters.Add("@rsnum", SqlDbType.Int).Value = reserve_id;
            sda.Parameters.Add("@rsnum", SqlDbType.Int).Value = roomNumber;
            sda.Parameters.Add("@cid", SqlDbType.Int).Value = id;
            sda.Parameters.Add("@in", SqlDbType.Date).Value = dateIN;
            sda.Parameters.Add("@out", SqlDbType.Date).Value = dateOUT;

            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //======================================================================

        public bool delete_Reservation(int reserve_id)
        {
            // con.Open();
            SqlCommand sda = new SqlCommand();
            String qry = "delete from [HotelSystem].[dbo].[reservation] WHERE reserve_id= @num";

            sda.CommandText = qry;
            sda.Connection = con;

            sda.Parameters.Add("@num", SqlDbType.Int).Value = reserve_id;
            con.Open();

            if (sda.ExecuteNonQuery() == 1)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        //=======================================================================
    }
}
